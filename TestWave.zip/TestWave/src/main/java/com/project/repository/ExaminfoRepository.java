package com.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.model.ExamDetails;

public interface ExaminfoRepository extends JpaRepository<ExamDetails, Long>{
	ExamDetails findByUserName(String username);
}
