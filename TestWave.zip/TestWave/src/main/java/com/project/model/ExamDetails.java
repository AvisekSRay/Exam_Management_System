package com.project.model;

import java.time.LocalDate;
import java.time.LocalTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class ExamDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long eid;
	
	@Column(nullable = true, columnDefinition = "VARCHAR(255) DEFAULT ''")
	private String userName;
	
	@Column(nullable = true, columnDefinition = "VARCHAR(255) DEFAULT ''")
	private String course;
	
	private LocalDate examDate;
	
	private LocalTime examTime;
	
	@Column(nullable = true, columnDefinition = "VARCHAR(255) DEFAULT ''")
	private Long result;
	
	@Column(nullable = true, columnDefinition = "VARCHAR(255) DEFAULT ''")
	private String status;
	
	public ExamDetails(){

	}

	public ExamDetails(String userName, String course, LocalDate examDate, LocalTime examTime, Long result,
			String status) {
		super();
		this.userName = userName;
		this.course = course;
		this.examDate = examDate;
		this.examTime = examTime;
		this.result = result;
		this.status = status;
	}

	public Long getEid() {
		return eid;
	}

	public void setEid(Long eid) {
		this.eid = eid;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public LocalDate getExamDate() {
		return examDate;
	}

	public void setExamDate(LocalDate examDate) {
		this.examDate = examDate;
	}

	public LocalTime getExamTime() {
		return examTime;
	}

	public void setExamTime(LocalTime examTime) {
		this.examTime = examTime;
	}

	public Long getResult() {
		return result;
	}

	public void setResult(Long result) {
		this.result = result;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	
	
	
}
