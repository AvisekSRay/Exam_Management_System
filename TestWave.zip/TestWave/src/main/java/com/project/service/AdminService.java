package com.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.model.Admin;
import com.project.repository.AdminRepository;



@Service
public class AdminService {
	
	@Autowired
	private AdminRepository adminRepository;
	
	//Save Admin Details
	public void createUser(Admin admin)
	{
		adminRepository.save(admin);
	}
	
	//Admin Login Authentication
	public boolean authenticate(Admin admin) {

		Admin user1= adminRepository.findByUsername(admin.getUsername());
		return user1 !=null && user1.getPassword().equals(admin.getPassword());
	}
	
}
