package com.project.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.model.User;
import com.project.repository.UserRepository;


@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	//Save User
	public void createUser(User user)
	{
		userRepository.save(user);
	}
	
	
	//Login Authentication
	public boolean authenticate(User user) {

		User user1= userRepository.findByUsername(user.getUsername());
		return user1 !=null && user1.getPassword().equals(user.getPassword());
	}
	
	//User Details Page
	public User getUserByUsername(String username) {
		return userRepository.findByUsername(username);
	}
}
