package com.project.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.model.Question;
import com.project.repository.QuestionRepository;

@Controller
public class MockExamController {
	
    @Autowired
    private QuestionRepository questionRepository;
    
    //GetMapping For Adding Question
    @GetMapping("/admin/addQuestion")
    public String showAddQuestionForm(Model model) {
        model.addAttribute("question", new Question());
        return "addQuestion";
    }
    
    //AddQuestions
    @PostMapping("/admin/addQuestion")
    public String addQuestion(@ModelAttribute("question") Question question) {
        questionRepository.save(question);
        return "redirect:/admin/addQuestion";
    }
    
    //Get Exam Page
    @GetMapping("/exam")
    public String startExam(Model model) {
        List<Question> questions = questionRepository.findAll();
        model.addAttribute("questions", questions);
        return "exam";
    }
    
    //Exam module and result
    @PostMapping("/exam")
    public String submitExam(@RequestParam Map<String, String> answers, Model model) {
        int totalQuestions = answers.size();
        int correctAnswers = 0;
        for (Map.Entry<String, String> entry : answers.entrySet()) {
            Long questionId = Long.parseLong(entry.getKey());
            String selectedOption = entry.getValue();
            Question question = questionRepository.findById(questionId).orElse(null);
            if (question != null && question.getCorrectOption().equals(selectedOption)) {
                correctAnswers++;
            }
        }
        double percentage = (double) correctAnswers / totalQuestions * 100;
        model.addAttribute("totalQuestions", totalQuestions);
        model.addAttribute("correctAnswers", correctAnswers);
        model.addAttribute("percentage", percentage);
        return "examResult";
    }
	
}

