package com.project.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.project.model.User;
import com.project.repository.UserRepository;

import jakarta.servlet.http.HttpSession;

@Controller
public class PageController {
	
	@Autowired
	private UserRepository userRepository;
	
	
	//Display User Details on Admin Page
	@GetMapping("/admin1")
	public String createUsers(Model model) {
		List<User> users = userRepository.findAll();
		model.addAttribute("users",users);
		return "adminIndex";
	}
	
	//Login Page
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	
	//WrongCred
	@GetMapping("/wrong")
	public String wrongcred() {
		return "wrongcredentials";
	}
	
	//UserIndexPage
	@GetMapping("/home")
	public String homepage(HttpSession session,RedirectAttributes re) {
		if(session.getAttribute("loggedInUser") == null) {
			re.addFlashAttribute("Message","Login to view home page");
			return "redirect:/login";
		}
		return "userIndex";
	}

//	//Admin Index Page
//	@GetMapping("/admin")
//	public String adminindex() {
//		return "adminIndex";
//	}
	
	//Registration Page
	@GetMapping("/register")
	public String signup() {
		return "register";
	}
	
	//Admin Registration
	@GetMapping("/adminregister")
	public String adminregister() {
		return "adminregister";
	}
	//Admin Login
	@GetMapping("/admin")
	public String adminlogin() {
		return "adminlogin";
	}
	
}
