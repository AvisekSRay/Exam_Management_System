package com.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.model.ExamDetails;
import com.project.repository.ExaminfoRepository;


@Controller
public class ExaminfoController {
	
	@Autowired
	private ExaminfoRepository examinfoRepository;
	
	
	//Exam Date And Time
	@PostMapping("/examdetails")
    public String searchByUsernameDetails(@RequestParam("username") String username, Model model) {
        ExamDetails exams = examinfoRepository.findByUserName(username);
        if (exams != null) {
            model.addAttribute("exam", exams);
            return "examdetails"; // JSP page to display user exam details
        } else {
            return "redirect:/wrong"; // JSP page for user not found
        }
    }
	
	
	//Exam Result
	@PostMapping("/examreport")
    public String searchByUsernameReport(@RequestParam("username") String username, Model model) {
        ExamDetails exams = examinfoRepository.findByUserName(username);
        if (exams != null) {
            model.addAttribute("exam", exams);
            return "examreport"; // JSP page to display user result details
        } else {
            return "redirect:/wrong"; // JSP page for user not found
        }
    }
}
