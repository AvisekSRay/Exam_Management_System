package com.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.project.model.ExamDetails;
import com.project.repository.ExamRepository;

@Controller
@RequestMapping("/admin2")
public class ExamController {
	
	@Autowired
	private ExamRepository examRepository;
	
	
	@GetMapping
	public String createExams(Model model) {
		List<ExamDetails> exam = examRepository.findAll();
		model.addAttribute("exams", exam);
		return "list";
	}

	@GetMapping("/create")
	public String createExamForm(Model model) {
		ExamDetails exams= new ExamDetails();
		model.addAttribute("exam", exams);
		return "create";
	}

	@PostMapping("/create")
	public String createExam(@ModelAttribute ExamDetails exam) {
		examRepository.save(exam);
		return "redirect:/admin2";
	}

	@GetMapping("/edit/{id}")
	public String editExamForm(@PathVariable Long id, Model model) {
		ExamDetails exam = examRepository.findById(id)
				.orElseThrow(() -> new IllegalArgumentException("Invalid user id:" + id));
		model.addAttribute("exam", exam);
		return "edit";
	}

	@PostMapping("/edit/{id}")
	public String editExam(@PathVariable Long id, @ModelAttribute ExamDetails updatedExam) {
		examRepository.findById(id).ifPresent(exam -> {
			exam.setUserName(updatedExam.getUserName());
			exam.setCourse(updatedExam.getCourse());
			exam.setExamDate(updatedExam.getExamDate());
			exam.setExamTime(updatedExam.getExamTime());
			exam.setResult(updatedExam.getResult());
			exam.setStatus(updatedExam.getStatus());
			examRepository.save(exam);
			
		});
		return "redirect:/admin2";
	}

	@GetMapping("/delete/{id}")
	public String deleteExam(@PathVariable Long id) {
		examRepository.deleteById(id);
		return "redirect:/admin2";
	}
	
}
