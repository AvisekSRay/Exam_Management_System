package com.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.project.model.Admin;
import com.project.service.AdminService;

import ch.qos.logback.core.model.Model;
import jakarta.servlet.http.HttpSession;

@Controller
public class AdminController {
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private HttpSession httpSession;
	
	//Admin Registration
	@PostMapping("/adminregister")
	public String signup(Admin admin) {
		
		adminService.createUser(admin);
		return "redirect:/admin";
	}
	
	//Admin Login
	@PostMapping("/adminlogin")
	public String login(Admin login,Model model)
	{
		if (adminService.authenticate(login))
		{	
			httpSession.setAttribute("loggedInAdmin", login.getUsername());
			return "redirect:/admin1";
		}
		else
		{
			return "redirect:/admin";
		}
	}
	
}
