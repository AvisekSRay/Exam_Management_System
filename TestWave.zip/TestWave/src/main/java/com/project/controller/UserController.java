package com.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.project.model.User;
import com.project.service.UserService;

import ch.qos.logback.core.model.Model;
import jakarta.servlet.http.HttpSession;

@Controller
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private HttpSession httpSession;
	
	@PostMapping("/register")
	public String signup(User user) {
		
		userService.createUser(user);
		return "redirect:/login";
	}
	
	@PostMapping("/login")
	public String login(User login,Model model)
	{
		if (userService.authenticate(login))
		{
			httpSession.setAttribute("loggedInUser", login.getUsername());
			return "redirect:/home";
		}
		else
		{
			return "redirect:/wrong";
		}
	}
	
	
	@GetMapping("/logout")
	public String logout() {
		httpSession.invalidate();
		return "redirect:/login";
	}
}
