package com.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.project.model.User;
import com.project.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class UserDetailsController {
	
	@Autowired
	private UserService userService;
	
	@GetMapping("user/details")
	public ModelAndView getUserDetails(HttpSession session) {
		ModelAndView mav = new ModelAndView();
		String username = (String) session.getAttribute("loggedInUser");
		if(username != null) {
			User user = userService.getUserByUsername(username);
			mav.addObject("user",user);
			mav.setViewName("userdetails");
		}else {
			mav.setViewName("redirect:/login");
		}
		return mav;
	}
}
